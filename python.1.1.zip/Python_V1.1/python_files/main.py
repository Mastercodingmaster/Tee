idle = 0
print(idle)
