XYZ = print("Your X Y and Z is " + "10, 50, 40" )
ran = print("Graphis Is Completly DOODOO")
randomint = ran
prn = print(XYZ)
print(prn)
en = 0
we = 0
prn = print(en)
input_name = input("Hello What is Your name? ")
print("Hello " + input_name + "!")
input_password = input("What is Will Your Password Be ")
inputconfirmpwd = input("Confirm Your Password ")
music = print("The Ants Went Marching Down The Hill!")


