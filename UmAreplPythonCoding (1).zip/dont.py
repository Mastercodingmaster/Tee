en = 0
we = 0
prn = print(en/we)




